<?php

$id = $_SESSION['user_id'];

$wallet = FETCH_WALLET($id);

?>