<?php 

$all_blogs = ALL_BLOGS($conn);

?>