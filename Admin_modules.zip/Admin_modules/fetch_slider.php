<?php

$fetch_slider = FETCH_SLIDER();
?>