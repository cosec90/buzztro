<?php 


$prod_cat = CATEGORY_FETCH();
//pre_r($categorized_cards);

?>